# UTT-TN09

Template LaTeX minimaliste pour l'écriture des rapports TN09 de l'Université de Technologie de Troyes.

Le plan, l'overlay, ainsi que les recommandations sont basés sur le très officiel [carnet de stage](carnet_pour_A17-1.pdf).
