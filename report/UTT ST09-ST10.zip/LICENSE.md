"THE BEER-WARE LICENSE" (Revision 42):
<aurelien@labate.me> and <axel@mousset.me> wrote this template. As long as you retain this notice you
can do whatever you want with this stuff. If we meet some day, and you think
this stuff is worth it, you can buy me a beer in return.
Aurélien and Axel


"THE BEER-WARE LICENSE" (Revision 42):
<aurelien@labate.me> and <axel@mousset.me> ont créé ce template. Tant que vous conservez cet avertissement, vous pouvez faire ce que vous voulez de ce truc. Si on se rencontre un jour et que vous pensez que ce truc vaut le coup, vous pouvez nous payer une bière en retour.
Aurélien et Axel